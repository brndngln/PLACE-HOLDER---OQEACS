"""
Dummy handler module for testing architectural rule violations.
"""


def get_user(user_id: int):
    return {"id": user_id, "name": "John Doe"}
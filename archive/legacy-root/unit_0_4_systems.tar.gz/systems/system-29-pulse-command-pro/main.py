#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
╔════════════════════════════════════════════════════════════════════════════╗
║           PULSE COMMAND PRO — ANOMALY DETECTION SIDECAR SERVICE           ║
╚════════════════════════════════════════════════════════════════════════════╝

This module implements the anomaly detection component for Pulse Command Pro.
It continuously pulls metrics from Prometheus, applies statistical tests such
as z‑score and median absolute deviation (MAD) to identify outliers, and
persists notable anomalies to a PostgreSQL database. A FastAPI application
exposes REST endpoints for retrieving anomalies, triggering manual scans and
reporting service health. The design adheres to the Omni Quantum coding
standards: clear separation between repository and service layers, async
interaction with PostgreSQL via asyncpg, structured JSON logging via
structlog, and Prometheus metrics instrumentation.

Environment variables required:
    PULSE_DB_DSN          – PostgreSQL DSN for connecting to the anomalies database.
    PROMETHEUS_BASE_URL   – Base URL of the Prometheus API (e.g. http://omni-prometheus:9090).
    ANOMALY_METRICS       – Comma‑separated list of Prometheus metric names to monitor.
    SCAN_INTERVAL_SECONDS – Interval between anomaly scans (default: 60).

"""

from __future__ import annotations

import asyncio
import os
import statistics
from dataclasses import dataclass, field
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any, Dict, List, Optional

import asyncpg
import httpx
import structlog
from fastapi import BackgroundTasks, Depends, FastAPI, HTTPException, status
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from prometheus_client import Counter, Gauge, Histogram, make_asgi_app


###############################################################################
# CONFIGURATION AND LOGGING                                                    #
###############################################################################

logger = structlog.get_logger()

# Configure structlog for JSON output
structlog.configure(
    processors=[
        structlog.processors.TimeStamper(fmt="iso", utc=True),
        structlog.processors.JSONRenderer()
    ]
)


###############################################################################
# DATA MODELS                                                                  #
###############################################################################

class AnomalyCreate(BaseModel):
    """Schema for creating an anomaly record manually."""

    metric: str = Field(..., description="Name of the metric")
    value: Decimal = Field(..., description="Observed value")
    mean: Decimal = Field(..., description="Calculated mean of historical values")
    stddev: Decimal = Field(..., description="Calculated standard deviation")
    mad: Decimal = Field(..., description="Calculated median absolute deviation")
    metadata: Dict[str, Any] = Field(default_factory=dict)


class AnomalyRead(BaseModel):
    """Schema returned for reading an anomaly."""

    id: int
    metric: str
    value: Decimal
    mean: Decimal
    stddev: Decimal
    mad: Decimal
    created_at: datetime
    metadata: Dict[str, Any]


###############################################################################
# DATABASE LAYER                                                               #
###############################################################################

@dataclass
class AnomalyRecord:
    """Internal representation of an anomaly record."""

    id: int
    metric: str
    value: Decimal
    mean: Decimal
    stddev: Decimal
    mad: Decimal
    metadata: Dict[str, Any]
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


class AnomalyRepository:
    """Repository for persisting and retrieving anomaly records."""

    def __init__(self, pool: asyncpg.Pool) -> None:
        self._pool = pool

    @staticmethod
    async def create_pool(dsn: str) -> asyncpg.Pool:
        return await asyncpg.create_pool(dsn=dsn, min_size=1, max_size=5)

    async def record(self, anomaly: AnomalyRecord) -> int:
        query = (
            "INSERT INTO anomalies (metric, value, mean, stddev, mad, metadata, created_at)"
            " VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING id"
        )
        async with self._pool.acquire() as conn:
            record_id = await conn.fetchval(
                query,
                anomaly.metric,
                anomaly.value,
                anomaly.mean,
                anomaly.stddev,
                anomaly.mad,
                anomaly.metadata,
                anomaly.created_at,
            )
        return record_id

    async def list_recent(self, limit: int = 100) -> List[AnomalyRecord]:
        query = (
            "SELECT id, metric, value, mean, stddev, mad, metadata, created_at"
            " FROM anomalies ORDER BY created_at DESC LIMIT $1"
        )
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(query, limit)
        return [self._row_to_record(row) for row in rows]

    async def get(self, record_id: int) -> Optional[AnomalyRecord]:
        query = (
            "SELECT id, metric, value, mean, stddev, mad, metadata, created_at"
            " FROM anomalies WHERE id = $1"
        )
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(query, record_id)
        return self._row_to_record(row) if row else None

    @staticmethod
    def _row_to_record(row: asyncpg.Record) -> AnomalyRecord:
        return AnomalyRecord(
            id=row["id"],
            metric=row["metric"],
            value=row["value"],
            mean=row["mean"],
            stddev=row["stddev"],
            mad=row["mad"],
            metadata=row["metadata"],
            created_at=row["created_at"],
        )


###############################################################################
# SERVICE LAYER                                                                #
###############################################################################

class AnomalyService:
    """Business logic for anomaly detection and storage."""

    def __init__(self, repo: AnomalyRepository, prom_base_url: str, metrics: List[str]) -> None:
        self._repo = repo
        self._prom_base_url = prom_base_url.rstrip('/')
        self._metrics = metrics
        self._http_client = httpx.AsyncClient(timeout=10)
        # Prometheus metrics
        self._scan_count = Counter(
            'pulse_scan_total',
            'Total number of anomaly scans executed'
        )
        self._anomalies_found = Counter(
            'pulse_anomalies_detected_total',
            'Total number of anomalies detected'
        )
        self._scan_duration = Histogram(
            'pulse_scan_duration_seconds',
            'Duration of anomaly scan in seconds'
        )

    async def close(self) -> None:
        await self._http_client.aclose()

    async def detect_anomalies(self) -> None:
        """Iterate over configured metrics and detect anomalies."""
        for metric in self._metrics:
            await self._scan_metric(metric)

    async def _scan_metric(self, metric: str) -> None:
        with self._scan_duration.time():
            self._scan_count.inc()
            try:
                values = await self._fetch_metric_values(metric)
            except Exception as exc:  # noqa: BLE001
                logger.error('fetch_metric_failed', metric=metric, error=str(exc))
                return
            if not values:
                return
            latest_value = values[-1]
            mean = statistics.mean(values)
            stddev = statistics.pstdev(values) if len(values) > 1 else 0
            median = statistics.median(values)
            mad = statistics.median([abs(x - median) for x in values])
            threshold = mean + 3 * stddev
            if latest_value > threshold:
                self._anomalies_found.inc()
                anomaly = AnomalyRecord(
                    id=0,
                    metric=metric,
                    value=Decimal(str(latest_value)),
                    mean=Decimal(str(mean)),
                    stddev=Decimal(str(stddev)),
                    mad=Decimal(str(mad)),
                    metadata={"threshold": float(threshold)},
                    created_at=datetime.now(timezone.utc),
                )
                record_id = await self._repo.record(anomaly)
                logger.info('anomaly_detected', metric=metric, value=latest_value, record_id=record_id)

    async def _fetch_metric_values(self, metric: str) -> List[float]:
        """Fetch metric values from Prometheus for the last 10 minutes."""
        # Query range: last 10 minutes with 1m step
        end_ts = int(datetime.now(timezone.utc).timestamp())
        start_ts = end_ts - 600
        url = f"{self._prom_base_url}/api/v1/query_range"
        params = {
            "query": metric,
            "start": start_ts,
            "end": end_ts,
            "step": "60s",
        }
        response = await self._http_client.get(url, params=params)
        response.raise_for_status()
        data = response.json()
        if data.get("status") != "success":
            return []
        result = data.get("data", {}).get("result", [])
        if not result:
            return []
        # Assume single time series
        values = [float(value[1]) for value in result[0].get("values", [])]
        return values


###############################################################################
# FASTAPI INITIALIZATION                                                       #
###############################################################################

app = FastAPI(title="Pulse Command Pro Anomaly Service", version="1.0.0")

# Prometheus ASGI app for metrics exposure
app.mount("/metrics", make_asgi_app())

async def get_repo() -> AnomalyRepository:
    dsn = os.getenv("PULSE_DB_DSN")
    if not dsn:
        raise RuntimeError("PULSE_DB_DSN not set in environment")
    if not hasattr(get_repo, "_pool"):
        get_repo._pool = await AnomalyRepository.create_pool(dsn)  # type: ignore[attr-defined]
    return AnomalyRepository(get_repo._pool)  # type: ignore[attr-defined]

async def get_service(repo: AnomalyRepository = Depends(get_repo)) -> AnomalyService:
    prom_base = os.getenv("PROMETHEUS_BASE_URL", "http://omni-prometheus:9090")
    metrics_var = os.getenv("ANOMALY_METRICS", "up")
    metrics = [m.strip() for m in metrics_var.split(',') if m.strip()]
    if not hasattr(get_service, "_service"):
        get_service._service = AnomalyService(repo, prom_base, metrics)  # type: ignore[attr-defined]
    return get_service._service  # type: ignore[attr-defined]


###############################################################################
# ROUTES                                                                      #
###############################################################################

@app.get("/health", tags=["system"])
async def health() -> JSONResponse:
    return JSONResponse({"status": "ok"})


@app.get("/ready", tags=["system"])
async def ready(repo: AnomalyRepository = Depends(get_repo)) -> JSONResponse:
    try:
        # Simple readiness check: attempt a trivial query
        await repo.list_recent(limit=1)
    except Exception as exc:  # noqa: BLE001
        logger.error('readiness_failed', error=str(exc))
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Database unavailable")
    return JSONResponse({"status": "ready"})


@app.get("/api/v1/anomalies", response_model=List[AnomalyRead], tags=["anomalies"])
async def list_anomalies(limit: int = 100, repo: AnomalyRepository = Depends(get_repo)) -> List[AnomalyRead]:
    records = await repo.list_recent(limit)
    return [AnomalyRead(**record.__dict__) for record in records]


@app.get("/api/v1/anomalies/{record_id}", response_model=AnomalyRead, tags=["anomalies"])
async def get_anomaly(record_id: int, repo: AnomalyRepository = Depends(get_repo)) -> AnomalyRead:
    record = await repo.get(record_id)
    if not record:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Anomaly not found")
    return AnomalyRead(**record.__dict__)


@app.post("/api/v1/scan", tags=["anomalies"])
async def trigger_scan(background_tasks: BackgroundTasks, service: AnomalyService = Depends(get_service)) -> JSONResponse:
    """Trigger an immediate anomaly scan in the background."""
    background_tasks.add_task(service.detect_anomalies)
    return JSONResponse({"message": "Scan scheduled"})


###############################################################################
# BACKGROUND SCANNER                                                           #
###############################################################################

async def periodic_scan(service: AnomalyService, interval: int) -> None:
    """Continuously run anomaly scans at a fixed interval."""
    while True:
        try:
            await service.detect_anomalies()
        except Exception as exc:  # noqa: BLE001
            logger.error('periodic_scan_error', error=str(exc))
        await asyncio.sleep(interval)


@app.on_event("startup")
async def on_startup() -> None:
    repo = await get_repo()
    service = await get_service(repo)
    interval = int(os.getenv("SCAN_INTERVAL_SECONDS", "60"))
    asyncio.create_task(periodic_scan(service, interval))


@app.on_event("shutdown")
async def on_shutdown() -> None:
    service = await get_service()
    await service.close()

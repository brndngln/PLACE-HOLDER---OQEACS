# Pulse Command Pro

Pulse Command Pro is the anomaly detection sidecar for the Omni platform. It
monitors a configurable list of Prometheus metrics, applies statistical
techniques (mean, standard deviation and median absolute deviation) to detect
outliers and persists anomalies to a PostgreSQL database. A RESTful API allows
clients to query recent anomalies and trigger immediate scans, while the
service runs a periodic background scanner. Metrics are exposed via the
Prometheus `/metrics` endpoint for monitoring.

## Features

- **Continuous anomaly scanning** on Prometheus metrics using z‑score logic.
- **PostgreSQL persistence** of detected anomalies for historical analysis.
- **Structured JSON logging** via structlog for easy ingestion into log pipelines.
- **Prometheus instrumentation** for observability (scan counts, durations, anomaly counts).
- **Health and readiness endpoints** for Kubernetes or Compose orchestration.
- **Manual scan trigger** via POST `/api/v1/scan` endpoint.

## API

| Method | Path                     | Description                                   |
|-------:|-------------------------|-----------------------------------------------|
| GET    | `/health`               | Liveness probe returns `{ "status": "ok" }`   |
| GET    | `/ready`                | Readiness probe; checks DB connectivity       |
| GET    | `/metrics`              | Prometheus metrics exposition                 |
| GET    | `/api/v1/anomalies`     | List recent anomalies (query param `limit`)   |
| GET    | `/api/v1/anomalies/{id}`| Retrieve a single anomaly by its ID           |
| POST   | `/api/v1/scan`          | Trigger an immediate background anomaly scan  |

## Environment Variables

| Variable                 | Description                                                                      |
|--------------------------|----------------------------------------------------------------------------------|
| `PULSE_DB_DSN`           | PostgreSQL DSN used by asyncpg. Example: `postgresql://user:pass@host:5432/db`    |
| `PROMETHEUS_BASE_URL`    | Base URL for Prometheus HTTP API (default `http://omni-prometheus:9090`)          |
| `ANOMALY_METRICS`        | Comma‑separated list of Prometheus metrics to monitor (e.g. `up,cpu_usage`)      |
| `SCAN_INTERVAL_SECONDS`  | Interval between automatic scans (default `60`)                                  |

## Database Schema

See [`schema.sql`](schema.sql) for the full schema. The `anomalies` table
records each detected anomaly with associated statistics and metadata.

## Running locally

Ensure a running PostgreSQL instance and Prometheus server. Export required
environment variables, then run:

```bash
docker compose --env-file ../../.env -f docker-compose.yml up --build
```

The API will be available on port `9291`. Thanos components are exposed on
ports `9292` and `9293` for query and store respectively.

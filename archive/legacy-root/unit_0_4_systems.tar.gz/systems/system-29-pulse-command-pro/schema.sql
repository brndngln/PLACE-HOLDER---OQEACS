-- Schema for Pulse Command Pro anomaly detection service

CREATE TABLE IF NOT EXISTS anomalies (
    id SERIAL PRIMARY KEY,
    metric TEXT NOT NULL,
    value DECIMAL(20, 6) NOT NULL,
    mean DECIMAL(20, 6) NOT NULL,
    stddev DECIMAL(20, 6) NOT NULL,
    mad DECIMAL(20, 6) NOT NULL,
    metadata JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_anomalies_metric ON anomalies (metric);
CREATE INDEX IF NOT EXISTS idx_anomalies_created_at ON anomalies (created_at DESC);
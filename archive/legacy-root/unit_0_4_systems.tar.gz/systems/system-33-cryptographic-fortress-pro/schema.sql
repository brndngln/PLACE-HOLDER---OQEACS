-- Schema for Cryptographic Fortress Pro secret rotation history

CREATE TABLE IF NOT EXISTS secret_rotations (
    id SERIAL PRIMARY KEY,
    target TEXT NOT NULL,
    status TEXT NOT NULL,
    old_version INTEGER,
    new_version INTEGER,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_secret_rotations_created_at ON secret_rotations (created_at DESC);
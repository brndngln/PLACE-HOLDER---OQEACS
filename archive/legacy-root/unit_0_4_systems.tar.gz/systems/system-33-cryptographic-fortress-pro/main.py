#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
╔════════════════════════════════════════════════════════════════════════════╗
║        CRYPTOGRAPHIC FORTRESS PRO — SECRET ROTATION SERVICE              ║
╚════════════════════════════════════════════════════════════════════════════╝

This service automates the rotation of secrets stored in HashiCorp Vault and
other credential stores. It generates new random values, writes them back to
Vault and records rotation events in a PostgreSQL database. A FastAPI
application exposes endpoints to list rotation history and trigger manual
rotations. Periodic rotation runs according to a configurable interval.

Environment variables:
    ROTATE_DB_DSN            – PostgreSQL DSN for rotation history storage.
    VAULT_ADDR               – Base URL of the Vault server (e.g. http://omni-vault:8200).
    VAULT_TOKEN              – Token used to authenticate with Vault.
    ROTATION_TARGETS         – Comma‑separated list of Vault KV paths to rotate (e.g. secret/data/omni/postgres:db_password).
    ROTATION_INTERVAL_SEC    – Interval between automatic rotations (default 3600).

Each entry in `ROTATION_TARGETS` should be of the form `path:key`, where
`path` is the Vault KV path and `key` is the field within the secret.

"""

from __future__ import annotations

import asyncio
import os
import secrets
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import List, Optional, Tuple

import asyncpg
import hvac
import structlog
from fastapi import BackgroundTasks, Depends, FastAPI, HTTPException, status
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from prometheus_client import Counter, Histogram, make_asgi_app


###############################################################################
# CONFIGURATION AND LOGGING                                                    #
###############################################################################

logger = structlog.get_logger()
structlog.configure(
    processors=[
        structlog.processors.TimeStamper(fmt="iso", utc=True),
        structlog.processors.JSONRenderer()
    ]
)


###############################################################################
# DATA MODELS                                                                  #
###############################################################################

class RotationRead(BaseModel):
    id: int
    target: str
    status: str
    old_version: Optional[int]
    new_version: Optional[int]
    created_at: datetime


@dataclass
class RotationRecord:
    id: int
    target: str
    status: str
    old_version: Optional[int]
    new_version: Optional[int]
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


###############################################################################
# DATABASE LAYER                                                               #
###############################################################################

class RotationRepository:
    def __init__(self, pool: asyncpg.Pool) -> None:
        self._pool = pool

    @staticmethod
    async def create_pool(dsn: str) -> asyncpg.Pool:
        return await asyncpg.create_pool(dsn=dsn, min_size=1, max_size=5)

    async def record(self, target: str, status: str, old_version: Optional[int], new_version: Optional[int]) -> int:
        query = (
            "INSERT INTO secret_rotations (target, status, old_version, new_version)"
            " VALUES ($1, $2, $3, $4) RETURNING id"
        )
        async with self._pool.acquire() as conn:
            rotation_id = await conn.fetchval(query, target, status, old_version, new_version)
        return rotation_id

    async def list_rotations(self, limit: int = 50) -> List[RotationRecord]:
        query = (
            "SELECT id, target, status, old_version, new_version, created_at"
            " FROM secret_rotations ORDER BY created_at DESC LIMIT $1"
        )
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(query, limit)
        return [self._row_to_record(r) for r in rows]

    @staticmethod
    def _row_to_record(row: asyncpg.Record) -> RotationRecord:
        return RotationRecord(
            id=row["id"],
            target=row["target"],
            status=row["status"],
            old_version=row["old_version"],
            new_version=row["new_version"],
            created_at=row["created_at"],
        )


###############################################################################
# SERVICE LAYER                                                                #
###############################################################################

class RotationService:
    def __init__(self, repo: RotationRepository, vault_addr: str, vault_token: str, targets: List[Tuple[str, str]]) -> None:
        self._repo = repo
        self._client = hvac.Client(url=vault_addr, token=vault_token)
        self._targets = targets
        self._rotation_count = Counter('secret_rotation_total', 'Total number of secret rotations attempted')
        self._rotation_duration = Histogram('secret_rotation_duration_seconds', 'Duration of secret rotation cycles')

    async def rotate_all(self) -> None:
        with self._rotation_duration.time():
            for path, key in self._targets:
                await self._rotate(path, key)

    async def _rotate(self, path: str, key: str) -> None:
        self._rotation_count.inc()
        # Read existing secret
        try:
            read_resp = self._client.secrets.kv.v2.read_secret_version(path=path)
            data = read_resp['data']['data']
            old_version = read_resp['data']['metadata']['version']
        except Exception as exc:  # noqa: BLE001
            logger.error('vault_read_failed', path=path, error=str(exc))
            await self._repo.record(f"{path}:{key}", 'READ_FAILED', None, None)
            return
        # Generate new secret
        new_value = secrets.token_hex(32)
        data[key] = new_value
        try:
            write_resp = self._client.secrets.kv.v2.create_or_update_secret(path=path, secret=data)
            new_version = write_resp['data']['version']
            await self._repo.record(f"{path}:{key}", 'SUCCESS', old_version, new_version)
            logger.info('secret_rotated', path=path, key=key, old_version=old_version, new_version=new_version)
        except Exception as exc:  # noqa: BLE001
            logger.error('vault_write_failed', path=path, key=key, error=str(exc))
            await self._repo.record(f"{path}:{key}", 'WRITE_FAILED', old_version, None)


###############################################################################
# FASTAPI INITIALIZATION                                                       #
###############################################################################

app = FastAPI(title="Cryptographic Fortress Pro", version="1.0.0")
app.mount('/metrics', make_asgi_app())

async def get_repo() -> RotationRepository:
    dsn = os.getenv('ROTATE_DB_DSN')
    if not dsn:
        raise RuntimeError('ROTATE_DB_DSN is not configured')
    if not hasattr(get_repo, '_pool'):
        get_repo._pool = await RotationRepository.create_pool(dsn)  # type: ignore[attr-defined]
    return RotationRepository(get_repo._pool)  # type: ignore[attr-defined]

def parse_targets(spec: str) -> List[Tuple[str, str]]:
    targets: List[Tuple[str, str]] = []
    for item in spec.split(','):
        item = item.strip()
        if not item:
            continue
        if ':' not in item:
            raise RuntimeError(f'Invalid rotation target format: {item}')
        path, key = item.split(':', 1)
        targets.append((path, key))
    return targets

async def get_service(repo: RotationRepository = Depends(get_repo)) -> RotationService:
    vault_addr = os.getenv('VAULT_ADDR', 'http://omni-vault:8200')
    vault_token = os.getenv('VAULT_TOKEN')
    if not vault_token:
        raise RuntimeError('VAULT_TOKEN must be provided')
    targets_spec = os.getenv('ROTATION_TARGETS', '')
    targets = parse_targets(targets_spec)
    if not hasattr(get_service, '_service'):
        get_service._service = RotationService(repo, vault_addr, vault_token, targets)  # type: ignore[attr-defined]
    return get_service._service  # type: ignore[attr-defined]


###############################################################################
# ROUTES                                                                      #
###############################################################################

@app.get('/health', tags=['system'])
async def health() -> JSONResponse:
    return JSONResponse({'status': 'ok'})


@app.get('/ready', tags=['system'])
async def ready(repo: RotationRepository = Depends(get_repo)) -> JSONResponse:
    try:
        await repo.list_rotations(limit=1)
    except Exception as exc:  # noqa: BLE001
        logger.error('readiness_failed', error=str(exc))
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail='Database unavailable')
    return JSONResponse({'status': 'ready'})


@app.get('/api/v1/rotations', response_model=List[RotationRead], tags=['rotations'])
async def list_rotations(limit: int = 50, repo: RotationRepository = Depends(get_repo)) -> List[RotationRead]:
    records = await repo.list_rotations(limit)
    return [RotationRead(**record.__dict__) for record in records]


@app.post('/api/v1/rotate', tags=['rotations'])
async def trigger_rotation(background_tasks: BackgroundTasks, service: RotationService = Depends(get_service)) -> JSONResponse:
    background_tasks.add_task(service.rotate_all)
    return JSONResponse({'message': 'Rotation scheduled'})


###############################################################################
# BACKGROUND ROTATOR                                                          #
###############################################################################

async def periodic_rotate(service: RotationService, interval: int) -> None:
    while True:
        try:
            await service.rotate_all()
        except Exception as exc:  # noqa: BLE001
            logger.error('rotation_error', error=str(exc))
        await asyncio.sleep(interval)


@app.on_event('startup')
async def on_startup() -> None:
    repo = await get_repo()
    service = await get_service(repo)
    interval = int(os.getenv('ROTATION_INTERVAL_SEC', '3600'))
    asyncio.create_task(periodic_rotate(service, interval))


@app.on_event('shutdown')
async def on_shutdown() -> None:
    # Nothing to close for hvac client
    pass

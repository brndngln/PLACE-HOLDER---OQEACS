# Cryptographic Fortress Pro

Cryptographic Fortress Pro is responsible for rotating secrets across the Omni
platform. It integrates with HashiCorp Vault to read and update secret KV
entries, generates new random values and logs each rotation into a PostgreSQL
history table. The service runs periodic rotations at a configurable interval
and provides an API for listing history and triggering ad‑hoc rotations.

## Features

- **Vault integration**: uses the Vault API to fetch and update secret KV
  versions.
- **Automatic key generation**: new 32‑byte hex secrets are created for each
  rotation.
- **Rotation history**: records when and what secret field was rotated along
  with previous and new version numbers.
- **Prometheus metrics**: tracks the number and duration of rotation cycles.
- **REST API**: list past rotations and trigger a rotation manually.

## API

| Method | Path              | Description                                               |
|------:|------------------|-----------------------------------------------------------|
| GET   | `/health`        | Liveness probe                                             |
| GET   | `/ready`         | Readiness probe; verifies DB connectivity                  |
| GET   | `/metrics`       | Prometheus metrics                                          |
| GET   | `/api/v1/rotations`| List recent secret rotations (`limit` query param)         |
| POST  | `/api/v1/rotate` | Trigger rotation of all configured targets                 |

## Environment Variables

| Variable                   | Description                                                                                    |
|----------------------------|------------------------------------------------------------------------------------------------|
| `ROTATE_DB_DSN`            | PostgreSQL DSN for storing rotation history                                                      |
| `VAULT_ADDR`               | URL of the Vault server (default `http://omni-vault:8200`)                                      |
| `VAULT_TOKEN`              | Token for authenticating with Vault                                                             |
| `ROTATION_TARGETS`         | Comma‑separated list of `path:key` pairs to rotate (e.g. `secret/data/omni/postgres:db_password`) |
| `ROTATION_INTERVAL_SEC`    | Interval in seconds between automatic rotations (default `3600`)                                 |

## Database Schema

See [`schema.sql`](schema.sql) for the definition of the `secret_rotations` table.

## Running

After ensuring `.env` contains the necessary Vault and database connection
information, start the service with:

```bash
docker compose --env-file ../../.env -f docker-compose.yml up --build
```

The API will be available on port `9331` (with an additional port mapping on
`9332` pointing to the same service).

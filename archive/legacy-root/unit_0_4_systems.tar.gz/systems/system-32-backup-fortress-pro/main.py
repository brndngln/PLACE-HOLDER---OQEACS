#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
╔════════════════════════════════════════════════════════════════════════════╗
║           BACKUP FORTRESS PRO — BACKUP ORCHESTRATOR SERVICE               ║
╚════════════════════════════════════════════════════════════════════════════╝

Backup Fortress Pro coordinates scheduled backups of databases and other
Omni platform assets. It invokes `pg_dump` to snapshot PostgreSQL
databases, interacts with Restic to store data in an encrypted repository and
records backup job metadata in PostgreSQL. Backup tasks run asynchronously
according to a configurable interval. A REST API exposes the status of
recent backup jobs and allows manual triggers.

Environment variables:
    BACKUP_DB_DSN            – PostgreSQL DSN for persisting backup job records.
    PG_BACKUP_DSN_LIST       – Comma‑separated list of PostgreSQL DSNs to back up.
    BACKUP_TARGET            – Filesystem path where temporary backup files are stored (/data/backups).
    RESTIC_REPOSITORY        – Restic repository path (e.g. /data/restic)
    RESTIC_PASSWORD          – Restic repository password.
    BACKUP_INTERVAL_SECONDS  – Interval between scheduled backups (default: 3600).

"""

from __future__ import annotations

import asyncio
import os
import shlex
import shutil
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

import asyncpg
import structlog
from fastapi import BackgroundTasks, Depends, FastAPI, HTTPException, status
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from prometheus_client import Counter, Histogram, make_asgi_app


###############################################################################
# CONFIGURATION AND LOGGING                                                    #
###############################################################################

logger = structlog.get_logger()
structlog.configure(
    processors=[
        structlog.processors.TimeStamper(fmt="iso", utc=True),
        structlog.processors.JSONRenderer()
    ]
)


###############################################################################
# DATA MODELS                                                                  #
###############################################################################

class BackupJobRead(BaseModel):
    id: int
    target: str
    status: str
    started_at: datetime
    finished_at: Optional[datetime]
    log: Optional[str]


@dataclass
class BackupJobRecord:
    id: int
    target: str
    status: str
    log: Optional[str]
    started_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    finished_at: Optional[datetime] = None


###############################################################################
# DATABASE LAYER                                                               #
###############################################################################

class BackupRepository:
    def __init__(self, pool: asyncpg.Pool) -> None:
        self._pool = pool

    @staticmethod
    async def create_pool(dsn: str) -> asyncpg.Pool:
        return await asyncpg.create_pool(dsn=dsn, min_size=1, max_size=5)

    async def create_job(self, target: str, status: str, log: Optional[str] = None) -> int:
        query = (
            "INSERT INTO backup_jobs (target, status, log) VALUES ($1, $2, $3) RETURNING id"
        )
        async with self._pool.acquire() as conn:
            job_id = await conn.fetchval(query, target, status, log)
        return job_id

    async def update_job(self, job_id: int, status: str, log: Optional[str], finished_at: datetime) -> None:
        query = (
            "UPDATE backup_jobs SET status = $1, log = $2, finished_at = $3 WHERE id = $4"
        )
        async with self._pool.acquire() as conn:
            await conn.execute(query, status, log, finished_at, job_id)

    async def list_jobs(self, limit: int = 20) -> List[BackupJobRecord]:
        query = (
            "SELECT id, target, status, log, started_at, finished_at"
            " FROM backup_jobs ORDER BY started_at DESC LIMIT $1"
        )
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(query, limit)
        return [self._row_to_record(r) for r in rows]

    @staticmethod
    def _row_to_record(row: asyncpg.Record) -> BackupJobRecord:
        return BackupJobRecord(
            id=row["id"],
            target=row["target"],
            status=row["status"],
            log=row["log"],
            started_at=row["started_at"],
            finished_at=row["finished_at"],
        )


###############################################################################
# SERVICE LAYER                                                                #
###############################################################################

class BackupService:
    def __init__(self, repo: BackupRepository, pg_dsns: List[str], target_dir: Path) -> None:
        self._repo = repo
        self._pg_dsns = pg_dsns
        self._target_dir = target_dir
        self._backup_count = Counter('backup_jobs_total', 'Number of backup jobs executed')
        self._backup_duration = Histogram('backup_job_duration_seconds', 'Duration of backup jobs in seconds')

    async def perform_backup(self) -> None:
        """Perform backup of all configured DSNs and commit to restic."""
        job_id = await self._repo.create_job(target=str(self._target_dir), status='RUNNING')
        started_at = datetime.now(timezone.utc)
        log_lines: List[str] = []
        try:
            with self._backup_duration.time():
                self._backup_count.inc()
                # Ensure target directory exists
                self._target_dir.mkdir(parents=True, exist_ok=True)
                # Loop through DSNs and dump each
                for dsn in self._pg_dsns:
                    name = self._extract_db_name(dsn)
                    dump_file = self._target_dir / f"{name}-{int(started_at.timestamp())}.dump"
                    await self._pg_dump(dsn, dump_file)
                    log_lines.append(f"Dumped {name} to {dump_file}")
                # Run restic backup
                await self._restic_backup(self._target_dir)
                log_lines.append("Restic backup completed")
                status = 'SUCCESS'
        except Exception as exc:  # noqa: BLE001
            logger.error('backup_failed', error=str(exc))
            log_lines.append(f"Error: {exc}")
            status = 'FAILED'
        finished_at = datetime.now(timezone.utc)
        await self._repo.update_job(job_id, status, '\n'.join(log_lines), finished_at)

    async def _pg_dump(self, dsn: str, output_file: Path) -> None:
        """Run pg_dump for a given DSN and write to output_file."""
        # Convert DSN to connection parameters for pg_dump
        env = os.environ.copy()
        env['PGPASSWORD'] = self._parse_dsn_password(dsn)
        cmd = [
            'pg_dump',
            '--format=custom',
            '--file', str(output_file),
            dsn,
        ]
        logger.info('running_pg_dump', dsn=dsn, output=str(output_file))
        process = await asyncio.create_subprocess_exec(*cmd, env=env, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        stdout, stderr = await process.communicate()
        if process.returncode != 0:
            raise RuntimeError(f"pg_dump failed: {stderr.decode().strip()}")
        if stdout:
            logger.info('pg_dump_output', output=stdout.decode().strip())

    async def _restic_backup(self, target_dir: Path) -> None:
        """Run restic backup for the target directory."""
        env = os.environ.copy()
        repository = env.get('RESTIC_REPOSITORY')
        password = env.get('RESTIC_PASSWORD')
        if not repository or not password:
            raise RuntimeError('RESTIC_REPOSITORY or RESTIC_PASSWORD not set')
        cmd = [
            'restic',
            'backup',
            str(target_dir),
        ]
        logger.info('running_restic', repository=repository, target=str(target_dir))
        process = await asyncio.create_subprocess_exec(*cmd, env=env, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        stdout, stderr = await process.communicate()
        if process.returncode != 0:
            raise RuntimeError(f"restic backup failed: {stderr.decode().strip()}")
        if stdout:
            logger.info('restic_output', output=stdout.decode().strip())

    def _extract_db_name(self, dsn: str) -> str:
        # Simple parser to extract DB name from DSN
        # Expect dsn in form postgresql://user:pass@host:port/dbname
        try:
            return dsn.rsplit('/', 1)[1]
        except Exception:
            return 'database'

    def _parse_dsn_password(self, dsn: str) -> str:
        # Extract password from DSN; expects postgresql://user:pass@host:port/db
        try:
            creds = dsn.split('://', 1)[1].split('@', 1)[0]
            return creds.split(':', 1)[1]
        except Exception:
            return ''


###############################################################################
# FASTAPI INITIALIZATION                                                       #
###############################################################################

app = FastAPI(title="Backup Fortress Pro", version="1.0.0")
app.mount('/metrics', make_asgi_app())

async def get_repo() -> BackupRepository:
    dsn = os.getenv('BACKUP_DB_DSN')
    if not dsn:
        raise RuntimeError('BACKUP_DB_DSN not defined')
    if not hasattr(get_repo, '_pool'):
        get_repo._pool = await BackupRepository.create_pool(dsn)  # type: ignore[attr-defined]
    return BackupRepository(get_repo._pool)  # type: ignore[attr-defined]

async def get_service(repo: BackupRepository = Depends(get_repo)) -> BackupService:
    pg_list = [dsn.strip() for dsn in os.getenv('PG_BACKUP_DSN_LIST', '').split(',') if dsn.strip()]
    target_dir = Path(os.getenv('BACKUP_TARGET', '/data/backups'))
    if not hasattr(get_service, '_service'):
        get_service._service = BackupService(repo, pg_list, target_dir)  # type: ignore[attr-defined]
    return get_service._service  # type: ignore[attr-defined]


###############################################################################
# ROUTES                                                                      #
###############################################################################

@app.get('/health', tags=['system'])
async def health() -> JSONResponse:
    return JSONResponse({'status': 'ok'})


@app.get('/ready', tags=['system'])
async def ready(repo: BackupRepository = Depends(get_repo)) -> JSONResponse:
    try:
        await repo.list_jobs(limit=1)
    except Exception as exc:  # noqa: BLE001
        logger.error('readiness_failed', error=str(exc))
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail='Database unavailable')
    return JSONResponse({'status': 'ready'})


@app.get('/api/v1/jobs', response_model=List[BackupJobRead], tags=['jobs'])
async def list_jobs(limit: int = 20, repo: BackupRepository = Depends(get_repo)) -> List[BackupJobRead]:
    records = await repo.list_jobs(limit)
    return [BackupJobRead(**record.__dict__) for record in records]


@app.post('/api/v1/backup', tags=['jobs'])
async def trigger_backup(background_tasks: BackgroundTasks, service: BackupService = Depends(get_service)) -> JSONResponse:
    background_tasks.add_task(service.perform_backup)
    return JSONResponse({'message': 'Backup scheduled'})


###############################################################################
# BACKGROUND SCHEDULER                                                        #
###############################################################################

async def periodic_backup(service: BackupService, interval: int) -> None:
    while True:
        try:
            await service.perform_backup()
        except Exception as exc:  # noqa: BLE001
            logger.error('backup_job_error', error=str(exc))
        await asyncio.sleep(interval)


@app.on_event('startup')
async def on_startup() -> None:
    repo = await get_repo()
    service = await get_service(repo)
    interval = int(os.getenv('BACKUP_INTERVAL_SECONDS', '3600'))
    asyncio.create_task(periodic_backup(service, interval))


@app.on_event('shutdown')
async def on_shutdown() -> None:
    # nothing to close currently
    pass

-- Schema for Backup Fortress Pro

CREATE TABLE IF NOT EXISTS backup_jobs (
    id SERIAL PRIMARY KEY,
    target TEXT NOT NULL,
    status TEXT NOT NULL,
    log TEXT,
    started_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    finished_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_backup_jobs_started_at ON backup_jobs (started_at DESC);
# Backup Fortress Pro

Backup Fortress Pro is the heart of the Omni platform's backup strategy. It
coordinates snapshotting of PostgreSQL databases using `pg_dump` and commits
those snapshots to a Restic repository for encryption and deduplication. Backup
jobs are recorded in a PostgreSQL table to provide auditability. A REST API
allows operators to inspect recent backups and manually trigger a new backup.

## Features

- **Scheduled backups** of one or more PostgreSQL databases.
- **Restic integration** to store encrypted, deduplicated snapshots.
- **Audit trail** of backup jobs with status and logs.
- **Prometheus metrics** exposing counts and durations of backups.
- **API for listing jobs** and manually triggering backups.

## API

| Method | Path               | Description                                                   |
|------:|-------------------|---------------------------------------------------------------|
| GET   | `/health`         | Liveness probe                                                |
| GET   | `/ready`          | Readiness probe; checks job table access                     |
| GET   | `/metrics`        | Prometheus metrics                                            |
| GET   | `/api/v1/jobs`    | List recent backup jobs (`limit` query param)                 |
| POST  | `/api/v1/backup`  | Trigger an immediate backup in the background                 |

## Environment Variables

| Variable                    | Description                                                                                       |
|-----------------------------|---------------------------------------------------------------------------------------------------|
| `BACKUP_DB_DSN`             | DSN for the internal backups database                                                             |
| `PG_BACKUP_DSN_LIST`        | Comma‑separated list of PostgreSQL DSNs to back up                                                |
| `BACKUP_TARGET`             | Directory used to store temporary dump files before restic snapshot (default `/data/backups`)    |
| `RESTIC_REPOSITORY`         | Path to the restic repository (default `/data/restic`)                                            |
| `RESTIC_PASSWORD`           | Password for the restic repository                                                                |
| `BACKUP_INTERVAL_SECONDS`   | Interval in seconds between scheduled backups (default `3600`)                                    |

## Database Schema

The [`schema.sql`](schema.sql) file defines a single table, `backup_jobs`,
which tracks each backup job's target, status, logs and timestamps.

## Running

Ensure that restic is initialized (`restic init`) at the repository path and
that PostgreSQL and pg_dump are accessible within the container. Then run:

```bash
docker compose --env-file ../../.env -f docker-compose.yml up --build
```

The API will be available on port `9321`; a second mapping on `9322` also
forwards to the same service for convenience.

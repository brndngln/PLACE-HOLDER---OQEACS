# Guardian Eye

Guardian Eye is a sidecar service that automates the configuration of
[Uptime Kuma](https://github.com/louislam/uptime-kuma) to monitor all services
within the Omni platform. On a regular schedule, it registers each service
defined in the `SERVICE_REGISTRY` environment variable with Uptime Kuma using
its HTTP API. Monitor metadata is stored in PostgreSQL for auditing and the
service exposes a small API for listing monitors and triggering manual
registrations.

## Features

- **Automatic monitor registration** for all Omni services via Uptime Kuma API.
- **Database persistence** of monitor definitions and Kuma IDs.
- **Periodic refreshes** to detect and register new services.
- **Prometheus metrics** for registration attempts and durations.
- **Health and readiness endpoints** for orchestration.

## API

| Method | Path                 | Description                                                       |
|------:|---------------------|-------------------------------------------------------------------|
| GET   | `/health`           | Liveness probe                                                     |
| GET   | `/ready`            | Readiness probe; verifies DB access                                 |
| GET   | `/metrics`          | Prometheus metrics                                                  |
| GET   | `/api/v1/monitors`  | List registered monitors                                            |
| POST  | `/api/v1/register`  | Trigger a manual monitor registration cycle in the background      |

## Environment Variables

| Variable                    | Description                                                                            |
|-----------------------------|----------------------------------------------------------------------------------------|
| `MONITOR_DB_DSN`            | PostgreSQL DSN used for persisting monitor records                                      |
| `UPTIME_KUMA_BASE_URL`      | Base URL of the Uptime Kuma instance (default `http://omni-uptime-kuma:3001`)            |
| `UPTIME_KUMA_API_KEY`       | API key for authenticating with Uptime Kuma                                             |
| `SERVICE_REGISTRY`          | JSON array describing services, e.g. `[{"name": "gitea", "url": "http://omni-gitea:3000"}]` |
| `REGISTER_INTERVAL_SEC`     | Interval between automatic registration cycles (default `300`)                          |

## Database Schema

See [`schema.sql`](schema.sql) for the `monitors` table definition.

## Running

Guardian Eye runs alongside Uptime Kuma. Use the provided `docker-compose.yml`:

```bash
docker compose --env-file ../../.env -f docker-compose.yml up --build
```

Uptime Kuma will be available on port `3001` and the Guardian Eye API on port
`3002`.

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
╔════════════════════════════════════════════════════════════════════════════╗
║              GUARDIAN EYE — UPTIME MONITOR REGISTRATION SERVICE            ║
╚════════════════════════════════════════════════════════════════════════════╝

Guardian Eye is a companion sidecar for Uptime Kuma. On startup and at
configurable intervals, it registers all Omni platform services as monitors
with an Uptime Kuma instance. The list of services is provided via an
environment variable `SERVICE_REGISTRY` in JSON format. Each monitor is
recorded in a PostgreSQL database. The service exposes a small API to list
monitors and manually trigger re‑registration.

Required environment variables:
    MONITOR_DB_DSN         – PostgreSQL DSN for monitor storage.
    UPTIME_KUMA_BASE_URL   – Base URL for the Uptime Kuma API (e.g. http://omni-uptime-kuma:3001).
    UPTIME_KUMA_API_KEY    – API key for authenticating with Uptime Kuma.
    SERVICE_REGISTRY       – JSON array of {"name": str, "url": str} describing services.
    REGISTER_INTERVAL_SEC  – Interval in seconds between registration cycles (default 300).

"""

from __future__ import annotations

import asyncio
import json
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import asyncpg
import httpx
import structlog
from fastapi import BackgroundTasks, Depends, FastAPI, HTTPException, status
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from prometheus_client import Counter, Histogram, make_asgi_app


###############################################################################
# CONFIGURATION AND LOGGING                                                    #
###############################################################################

logger = structlog.get_logger()

structlog.configure(
    processors=[
        structlog.processors.TimeStamper(fmt="iso", utc=True),
        structlog.processors.JSONRenderer()
    ]
)


###############################################################################
# DATA MODELS                                                                  #
###############################################################################

class MonitorRead(BaseModel):
    id: int
    name: str
    url: str
    kuma_id: Optional[int]
    created_at: datetime
    updated_at: datetime


@dataclass
class MonitorRecord:
    id: int
    name: str
    url: str
    kuma_id: Optional[int]
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


###############################################################################
# DATABASE LAYER                                                               #
###############################################################################

class MonitorRepository:
    def __init__(self, pool: asyncpg.Pool) -> None:
        self._pool = pool

    @staticmethod
    async def create_pool(dsn: str) -> asyncpg.Pool:
        return await asyncpg.create_pool(dsn=dsn, min_size=1, max_size=5)

    async def upsert_monitor(self, name: str, url: str, kuma_id: Optional[int]) -> int:
        async with self._pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    "SELECT id FROM monitors WHERE name = $1",
                    name,
                )
                if row:
                    await conn.execute(
                        "UPDATE monitors SET url = $1, kuma_id = $2, updated_at = $3 WHERE id = $4",
                        url,
                        kuma_id,
                        datetime.now(timezone.utc),
                        row["id"],
                    )
                    return row["id"]
                else:
                    inserted = await conn.fetchrow(
                        "INSERT INTO monitors (name, url, kuma_id) VALUES ($1, $2, $3) RETURNING id",
                        name,
                        url,
                        kuma_id,
                    )
                    return inserted["id"]

    async def list_monitors(self) -> List[MonitorRecord]:
        query = "SELECT id, name, url, kuma_id, created_at, updated_at FROM monitors ORDER BY name"
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(query)
        return [self._row_to_record(r) for r in rows]

    @staticmethod
    def _row_to_record(row: asyncpg.Record) -> MonitorRecord:
        return MonitorRecord(
            id=row["id"],
            name=row["name"],
            url=row["url"],
            kuma_id=row["kuma_id"],
            created_at=row["created_at"],
            updated_at=row["updated_at"],
        )


###############################################################################
# SERVICE LAYER                                                                #
###############################################################################

class GuardianService:
    """Service for registering monitors with Uptime Kuma."""

    def __init__(self, repo: MonitorRepository, kuma_base: str, api_key: str, registry: List[Dict[str, Any]]) -> None:
        self._repo = repo
        self._kuma_base = kuma_base.rstrip('/')
        self._api_key = api_key
        self._registry = registry
        self._http_client = httpx.AsyncClient(timeout=10)
        self._registration_count = Counter('guardian_registration_total', 'Total number of monitor registrations attempted')
        self._registration_duration = Histogram('guardian_registration_duration_seconds', 'Duration of monitor registration cycle')

    async def close(self) -> None:
        await self._http_client.aclose()

    async def register_all(self) -> None:
        """Register all configured services with Uptime Kuma."""
        with self._registration_duration.time():
            for svc in self._registry:
                await self._register_monitor(svc["name"], svc["url"])

    async def _register_monitor(self, name: str, url: str) -> None:
        self._registration_count.inc()
        # Attempt to register with Kuma API
        kuma_id: Optional[int] = None
        try:
            request_body = {
                "name": name,
                "url": url,
                "type": "http",
                "interval": 60,
                "retryInterval": 30,
            }
            headers = {"Authorization": f"Bearer {self._api_key}", "Content-Type": "application/json"}
            resp = await self._http_client.post(f"{self._kuma_base}/api/monitors", json=request_body, headers=headers)
            if resp.status_code in (200, 201):
                data = resp.json()
                kuma_id = data.get("id") or data.get("monitorID")
                logger.info('monitor_registered', name=name, url=url, kuma_id=kuma_id)
            else:
                logger.error('monitor_registration_failed', name=name, status=resp.status_code, body=await resp.aread())
        except Exception as exc:  # noqa: BLE001
            logger.error('monitor_registration_exception', name=name, error=str(exc))
        finally:
            # Persist regardless of success; kuma_id may be None
            await self._repo.upsert_monitor(name, url, kuma_id)


###############################################################################
# FASTAPI INITIALIZATION                                                       #
###############################################################################

app = FastAPI(title="Guardian Eye", version="1.0.0")
app.mount("/metrics", make_asgi_app())

async def get_repo() -> MonitorRepository:
    dsn = os.getenv('MONITOR_DB_DSN')
    if not dsn:
        raise RuntimeError('MONITOR_DB_DSN is not configured')
    if not hasattr(get_repo, '_pool'):
        get_repo._pool = await MonitorRepository.create_pool(dsn)  # type: ignore[attr-defined]
    return MonitorRepository(get_repo._pool)  # type: ignore[attr-defined]

async def get_service(repo: MonitorRepository = Depends(get_repo)) -> GuardianService:
    kuma_base = os.getenv('UPTIME_KUMA_BASE_URL', 'http://omni-uptime-kuma:3001')
    api_key = os.getenv('UPTIME_KUMA_API_KEY', '')
    registry_json = os.getenv('SERVICE_REGISTRY', '[]')
    try:
        registry = json.loads(registry_json)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f'Invalid SERVICE_REGISTRY JSON: {exc}')
    if not hasattr(get_service, '_service'):
        get_service._service = GuardianService(repo, kuma_base, api_key, registry)  # type: ignore[attr-defined]
    return get_service._service  # type: ignore[attr-defined]


###############################################################################
# ROUTES                                                                      #
###############################################################################

@app.get('/health', tags=['system'])
async def health() -> JSONResponse:
    return JSONResponse({'status': 'ok'})


@app.get('/ready', tags=['system'])
async def ready(repo: MonitorRepository = Depends(get_repo)) -> JSONResponse:
    try:
        await repo.list_monitors()
    except Exception as exc:  # noqa: BLE001
        logger.error('readiness_failed', error=str(exc))
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail='Database unavailable')
    return JSONResponse({'status': 'ready'})


@app.get('/api/v1/monitors', response_model=List[MonitorRead], tags=['monitors'])
async def list_monitors(repo: MonitorRepository = Depends(get_repo)) -> List[MonitorRead]:
    records = await repo.list_monitors()
    return [MonitorRead(**record.__dict__) for record in records]


@app.post('/api/v1/register', tags=['monitors'])
async def trigger_registration(background_tasks: BackgroundTasks, service: GuardianService = Depends(get_service)) -> JSONResponse:
    background_tasks.add_task(service.register_all)
    return JSONResponse({'message': 'Registration scheduled'})


###############################################################################
# BACKGROUND REGISTRATION                                                      #
###############################################################################

async def periodic_register(service: GuardianService, interval: int) -> None:
    while True:
        try:
            await service.register_all()
        except Exception as exc:  # noqa: BLE001
            logger.error('registration_error', error=str(exc))
        await asyncio.sleep(interval)


@app.on_event('startup')
async def on_startup() -> None:
    repo = await get_repo()
    service = await get_service(repo)
    interval = int(os.getenv('REGISTER_INTERVAL_SEC', '300'))
    asyncio.create_task(periodic_register(service, interval))


@app.on_event('shutdown')
async def on_shutdown() -> None:
    service = await get_service()
    await service.close()

-- Schema for Guardian Eye monitor service

CREATE TABLE IF NOT EXISTS monitors (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    url TEXT NOT NULL,
    kuma_id INTEGER,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Automatically update updated_at on row changes
CREATE OR REPLACE FUNCTION update_monitors_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS tr_monitors_updated_at ON monitors;
CREATE TRIGGER tr_monitors_updated_at
BEFORE UPDATE ON monitors
FOR EACH ROW EXECUTE PROCEDURE update_monitors_updated_at();
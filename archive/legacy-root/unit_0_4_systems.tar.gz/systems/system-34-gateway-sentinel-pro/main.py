#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
╔════════════════════════════════════════════════════════════════════════════╗
║          GATEWAY SENTINEL PRO — TRAEFIK MANAGEMENT AGENT                 ║
╚════════════════════════════════════════════════════════════════════════════╝

Gateway Sentinel Pro provides a management API and scheduler for dynamic
Traefik configuration. It stores gateway routing rules in PostgreSQL, writes
them to a dynamic configuration file consumed by Traefik's file provider
and applies advanced capabilities such as rate limiting and IP allow listing.

Environment variables:
    GATEWAY_DB_DSN           – PostgreSQL DSN for rule storage.
    TRAEFIK_DYNAMIC_CONFIG   – Absolute path to the dynamic config YAML written by this service.
    CONFIG_UPDATE_INTERVAL    – Interval in seconds to periodically rewrite the config file (default 300).

"""

from __future__ import annotations

import asyncio
import os
import yaml
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional

import asyncpg
import structlog
from fastapi import BackgroundTasks, Depends, FastAPI, HTTPException, status
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field, validator
from prometheus_client import Counter, Histogram, make_asgi_app


###############################################################################
# CONFIGURATION AND LOGGING                                                    #
###############################################################################

logger = structlog.get_logger()
structlog.configure(
    processors=[
        structlog.processors.TimeStamper(fmt="iso", utc=True),
        structlog.processors.JSONRenderer()
    ]
)


###############################################################################
# DATA MODELS                                                                  #
###############################################################################

class GatewayRuleCreate(BaseModel):
    domain: str = Field(..., description="Hostname to match")
    target: str = Field(..., description="Upstream URL (including scheme)")
    allowed_ips: List[str] = Field(default_factory=list, description="CIDR blocks allowed to access")
    rate_average: int = Field(100, description="Average requests per second allowed")
    rate_burst: int = Field(50, description="Burst capacity")

    @validator('target')
    def validate_target(cls, v: str) -> str:
        if not v.startswith(('http://', 'https://')):
            raise ValueError('target must include a scheme (http:// or https://)')
        return v

class GatewayRuleRead(BaseModel):
    id: int
    domain: str
    target: str
    allowed_ips: List[str]
    rate_average: int
    rate_burst: int
    created_at: datetime
    updated_at: datetime


@dataclass
class GatewayRuleRecord:
    id: int
    domain: str
    target: str
    allowed_ips: List[str]
    rate_average: int
    rate_burst: int
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


###############################################################################
# DATABASE LAYER                                                               #
###############################################################################

class GatewayRepository:
    def __init__(self, pool: asyncpg.Pool) -> None:
        self._pool = pool

    @staticmethod
    async def create_pool(dsn: str) -> asyncpg.Pool:
        return await asyncpg.create_pool(dsn=dsn, min_size=1, max_size=5)

    async def create_rule(self, rule: GatewayRuleCreate) -> int:
        query = (
            "INSERT INTO gateway_rules (domain, target, allowed_ips, rate_average, rate_burst)"
            " VALUES ($1, $2, $3, $4, $5) RETURNING id"
        )
        async with self._pool.acquire() as conn:
            new_id = await conn.fetchval(query, rule.domain, rule.target, rule.allowed_ips, rule.rate_average, rule.rate_burst)
        return new_id

    async def list_rules(self) -> List[GatewayRuleRecord]:
        query = (
            "SELECT id, domain, target, allowed_ips, rate_average, rate_burst, created_at, updated_at"
            " FROM gateway_rules ORDER BY created_at"
        )
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(query)
        return [self._row_to_record(r) for r in rows]

    async def update_config_file(self, rules: List[GatewayRuleRecord], file_path: Path) -> None:
        """Render the dynamic config YAML for Traefik and write it atomically."""
        http_cfg = {"routers": {}, "services": {}, "middlewares": {}}
        for rule in rules:
            suffix = str(rule.id)
            router_name = f"rule-{suffix}"
            service_name = f"svc-{suffix}"
            rate_name = f"rate-{suffix}"
            ip_name = f"whitelist-{suffix}"
            http_cfg["routers"][router_name] = {
                "rule": f"Host(`{rule.domain}`)",
                "service": service_name,
                "middlewares": [rate_name, ip_name],
            }
            http_cfg["services"][service_name] = {
                "loadBalancer": {
                    "servers": [ {"url": rule.target} ]
                }
            }
            http_cfg["middlewares"][rate_name] = {
                "rateLimit": {
                    "average": rule.rate_average,
                    "burst": rule.rate_burst,
                }
            }
            http_cfg["middlewares"][ip_name] = {
                "ipWhiteList": {
                    "sourceRange": rule.allowed_ips or ["0.0.0.0/0"]
                }
            }
        full_cfg = {"http": http_cfg}
        temp_path = file_path.with_suffix('.tmp')
        with temp_path.open('w') as f:
            yaml.safe_dump(full_cfg, f)
        temp_path.replace(file_path)
        logger.info('dynamic_config_updated', path=str(file_path), rules=len(rules))

    @staticmethod
    def _row_to_record(row: asyncpg.Record) -> GatewayRuleRecord:
        return GatewayRuleRecord(
            id=row['id'],
            domain=row['domain'],
            target=row['target'],
            allowed_ips=row['allowed_ips'],
            rate_average=row['rate_average'],
            rate_burst=row['rate_burst'],
            created_at=row['created_at'],
            updated_at=row['updated_at'],
        )


###############################################################################
# SERVICE LAYER                                                                #
###############################################################################

class GatewayService:
    def __init__(self, repo: GatewayRepository, config_path: Path) -> None:
        self._repo = repo
        self._config_path = config_path
        self._update_count = Counter('gateway_config_update_total', 'Number of config file writes')
        self._update_duration = Histogram('gateway_config_update_duration_seconds', 'Duration of config writes in seconds')

    async def create_rule(self, rule: GatewayRuleCreate) -> int:
        rule_id = await self._repo.create_rule(rule)
        await self.rewrite_config()
        return rule_id

    async def list_rules(self) -> List[GatewayRuleRecord]:
        return await self._repo.list_rules()

    async def rewrite_config(self) -> None:
        with self._update_duration.time():
            rules = await self._repo.list_rules()
            await self._repo.update_config_file(rules, self._config_path)
            self._update_count.inc()


###############################################################################
# FASTAPI INITIALIZATION                                                       #
###############################################################################

app = FastAPI(title="Gateway Sentinel Pro", version="1.0.0")
app.mount('/metrics', make_asgi_app())

async def get_repo() -> GatewayRepository:
    dsn = os.getenv('GATEWAY_DB_DSN')
    if not dsn:
        raise RuntimeError('GATEWAY_DB_DSN not configured')
    if not hasattr(get_repo, '_pool'):
        get_repo._pool = await GatewayRepository.create_pool(dsn)  # type: ignore[attr-defined]
    return GatewayRepository(get_repo._pool)  # type: ignore[attr-defined]

async def get_service(repo: GatewayRepository = Depends(get_repo)) -> GatewayService:
    config_path_str = os.getenv('TRAEFIK_DYNAMIC_CONFIG', '/data/traefik/dynamic.yaml')
    config_path = Path(config_path_str)
    if not hasattr(get_service, '_service'):
        get_service._service = GatewayService(repo, config_path)  # type: ignore[attr-defined]
    return get_service._service  # type: ignore[attr-defined]


###############################################################################
# ROUTES                                                                      #
###############################################################################

@app.get('/health', tags=['system'])
async def health() -> JSONResponse:
    return JSONResponse({'status': 'ok'})


@app.get('/ready', tags=['system'])
async def ready(repo: GatewayRepository = Depends(get_repo)) -> JSONResponse:
    try:
        await repo.list_rules()
    except Exception as exc:  # noqa: BLE001
        logger.error('readiness_failed', error=str(exc))
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail='Database unavailable')
    return JSONResponse({'status': 'ready'})


@app.get('/api/v1/rules', response_model=List[GatewayRuleRead], tags=['rules'])
async def list_rules(service: GatewayService = Depends(get_service)) -> List[GatewayRuleRead]:
    records = await service.list_rules()
    return [GatewayRuleRead(**record.__dict__) for record in records]


@app.post('/api/v1/rules', status_code=status.HTTP_201_CREATED, tags=['rules'])
async def create_rule(rule: GatewayRuleCreate, service: GatewayService = Depends(get_service)) -> JSONResponse:
    rule_id = await service.create_rule(rule)
    return JSONResponse({'id': rule_id})


###############################################################################
# BACKGROUND CONFIG REFRESH                                                    #
###############################################################################

async def periodic_rewrite(service: GatewayService, interval: int) -> None:
    while True:
        try:
            await service.rewrite_config()
        except Exception as exc:  # noqa: BLE001
            logger.error('config_rewrite_error', error=str(exc))
        await asyncio.sleep(interval)


@app.on_event('startup')
async def on_startup() -> None:
    repo = await get_repo()
    service = await get_service(repo)
    interval = int(os.getenv('CONFIG_UPDATE_INTERVAL', '300'))
    asyncio.create_task(periodic_rewrite(service, interval))


@app.on_event('shutdown')
async def on_shutdown() -> None:
    # Nothing to close
    pass

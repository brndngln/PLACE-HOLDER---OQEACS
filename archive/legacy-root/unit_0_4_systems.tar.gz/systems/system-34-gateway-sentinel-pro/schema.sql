-- Schema for Gateway Sentinel Pro

CREATE TABLE IF NOT EXISTS gateway_rules (
    id SERIAL PRIMARY KEY,
    domain TEXT NOT NULL UNIQUE,
    target TEXT NOT NULL,
    allowed_ips TEXT[] NOT NULL DEFAULT ARRAY['0.0.0.0/0'],
    rate_average INTEGER NOT NULL DEFAULT 100,
    rate_burst INTEGER NOT NULL DEFAULT 50,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE OR REPLACE FUNCTION update_gateway_rules_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS tr_gateway_rules_updated_at ON gateway_rules;
CREATE TRIGGER tr_gateway_rules_updated_at
BEFORE UPDATE ON gateway_rules
FOR EACH ROW EXECUTE PROCEDURE update_gateway_rules_updated_at();
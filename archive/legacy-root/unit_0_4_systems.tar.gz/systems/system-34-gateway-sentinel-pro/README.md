# Gateway Sentinel Pro

Gateway Sentinel Pro manages the Traefik gateway configuration for the Omni
platform. It provides an API to define routing rules (host → service)
complete with rate limiting and IP allow lists, persists those rules in
PostgreSQL and writes a dynamic configuration file consumed by Traefik's file
provider. The sidecar runs alongside Traefik, monitoring rule changes and
updating the configuration on a schedule or immediately after API changes.

## Features

- **Dynamic routing rules** persisted to PostgreSQL and rendered as YAML for
  Traefik's file provider.
- **Rate limiting and IP allow listing** per route via Traefik middleware.
- **REST API** for creating and listing rules.
- **Periodic config refresh** to ensure Traefik stays up‑to‑date.
- **Prometheus metrics** on config update counts and durations.
- **Health/readiness endpoints** for orchestration.

## API

| Method | Path            | Description                                                         |
|------:|----------------|---------------------------------------------------------------------|
| GET   | `/health`      | Liveness probe                                                      |
| GET   | `/ready`       | Readiness probe; verifies DB connectivity                           |
| GET   | `/metrics`     | Prometheus metrics                                                  |
| GET   | `/api/v1/rules`| List existing routing rules                                         |
| POST  | `/api/v1/rules`| Create a new routing rule; body must include `domain`, `target`, etc. |

### Rule Fields

- `domain`: hostname to match (e.g. `api.example.com`)
- `target`: upstream URL including scheme (e.g. `http://omni-service:8000`)
- `allowed_ips`: list of CIDR ranges allowed; defaults to `0.0.0.0/0`
- `rate_average`: average allowed requests per second (default 100)
- `rate_burst`: burst capacity (default 50)

## Environment Variables

| Variable                     | Description                                                          |
|------------------------------|----------------------------------------------------------------------|
| `GATEWAY_DB_DSN`             | DSN for storing gateway rules                                         |
| `TRAEFIK_DYNAMIC_CONFIG`     | Path to the YAML file written by the sidecar (`/data/traefik/dynamic.yaml`) |
| `CONFIG_UPDATE_INTERVAL`     | Seconds between periodic config re‑writes (default `300`)              |

## Database Schema

See [`schema.sql`](schema.sql) for the definition of the `gateway_rules` table.

## Running

Start both Traefik and the sentinel sidecar via the provided compose file:

```bash
docker compose --env-file ../../.env -f docker-compose.yml up --build
```

Traefik will listen on ports `80` and `443` and expose its dashboard on
`8080`. The Gateway Sentinel API will be available on port `9333` (with an
additional mapping on `9334`).

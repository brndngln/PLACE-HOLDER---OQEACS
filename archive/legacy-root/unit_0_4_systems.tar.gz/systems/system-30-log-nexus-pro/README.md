# Log Nexus Pro

Log Nexus Pro is the Omni platform's log pattern detection engine. It connects
to a Loki instance, streams log lines and leverages the Drain3 algorithm to
cluster messages into templates. New templates are persisted to a PostgreSQL
database for further inspection. The service exposes a REST API for listing
templates and manually triggering log polling and provides Prometheus metrics
for observability.

## Features

- **Drain3 log parsing** to group similar log messages into templates.
- **Loki integration**: fetches logs via the HTTP API.
- **Persistent storage** of templates with occurrence count.
- **Prometheus metrics** for polls, durations and new template counts.
- **Health/readiness endpoints** for orchestration.

## API

| Method | Path              | Description                                                   |
|------:|------------------|---------------------------------------------------------------|
| GET   | `/health`        | Liveness probe                                               |
| GET   | `/ready`         | Readiness probe; checks database connectivity                |
| GET   | `/metrics`       | Prometheus metrics                                           |
| GET   | `/api/v1/patterns`| List known log templates; optional `limit` query param        |
| POST  | `/api/v1/poll`    | Trigger an immediate log polling in background               |

## Environment Variables

| Variable                  | Description                                                   |
|---------------------------|---------------------------------------------------------------|
| `LOG_DB_DSN`              | PostgreSQL DSN for template storage                            |
| `LOKI_BASE_URL`           | Base URL of the Loki API (`http://omni-loki:3100` by default) |
| `LOG_QUERY`               | Loki log query to execute (`{job="app"}` by default)         |
| `POLL_INTERVAL_SECONDS`   | Interval between automatic log polls (default `60`)           |

## Database Schema

See [`schema.sql`](schema.sql) for the definition of the `log_patterns` table.

## Running

After ensuring `.env` is populated and Loki and PostgreSQL are running on the
Omni network, start the service with:

```bash
docker compose --env-file ../../.env -f docker-compose.yml up --build
```

The API will listen on port `9301` and metrics can also be accessed via port
`9302`.

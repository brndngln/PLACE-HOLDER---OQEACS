-- Schema for Log Nexus Pro log pattern detection

CREATE TABLE IF NOT EXISTS log_patterns (
    id SERIAL PRIMARY KEY,
    template TEXT NOT NULL UNIQUE,
    count INTEGER NOT NULL DEFAULT 1,
    metadata JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_log_patterns_updated_at ON log_patterns (updated_at DESC);

-- Update updated_at timestamp on change
CREATE OR REPLACE FUNCTION update_log_patterns_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS tr_log_patterns_updated_at ON log_patterns;
CREATE TRIGGER tr_log_patterns_updated_at
BEFORE UPDATE ON log_patterns
FOR EACH ROW EXECUTE PROCEDURE update_log_patterns_updated_at();
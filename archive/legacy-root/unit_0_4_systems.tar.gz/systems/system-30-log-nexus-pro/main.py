#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
╔════════════════════════════════════════════════════════════════════════════╗
║              LOG NEXUS PRO — LOG PATTERN DETECTION SERVICE               ║
╚════════════════════════════════════════════════════════════════════════════╝

This service continuously pulls logs from Loki, applies the Drain3 log parsing
algorithm to extract templates and identify novel log patterns. Detected
templates are persisted to PostgreSQL for future reference. A FastAPI
application exposes endpoints to retrieve current templates and to trigger
manual log polling. Metrics are exported via Prometheus for observability.

Environment variables:
    LOG_DB_DSN            – PostgreSQL DSN for log template storage.
    LOKI_BASE_URL         – Base URL of Loki HTTP API (e.g. http://omni-loki:3100).
    POLL_INTERVAL_SECONDS – Interval between log polling cycles (default: 60).
    LOG_QUERY             – Loki log query to fetch (default: '{job="app"}').

"""

from __future__ import annotations

import asyncio
import os
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import asyncpg
import httpx
import structlog
from drain3 import TemplateMiner
from drain3.template_miner_config import TemplateMinerConfig
from fastapi import BackgroundTasks, Depends, FastAPI, HTTPException, status
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from prometheus_client import Counter, Histogram, make_asgi_app


###############################################################################
# CONFIGURATION AND LOGGING                                                    #
###############################################################################

logger = structlog.get_logger()

structlog.configure(
    processors=[
        structlog.processors.TimeStamper(fmt="iso", utc=True),
        structlog.processors.JSONRenderer()
    ]
)


###############################################################################
# DATA MODELS                                                                  #
###############################################################################

class LogPatternRead(BaseModel):
    id: int
    template: str
    count: int
    created_at: datetime
    updated_at: datetime

class LogPatternCreate(BaseModel):
    template: str = Field(..., description="Drain3 template string")
    count: int = Field(1, description="Initial count")
    metadata: Dict[str, Any] = Field(default_factory=dict)


###############################################################################
# DATABASE LAYER                                                               #
###############################################################################

@dataclass
class LogPatternRecord:
    id: int
    template: str
    count: int
    metadata: Dict[str, Any]
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


class LogPatternRepository:
    """Repository for persisting Drain3 templates and counts."""

    def __init__(self, pool: asyncpg.Pool) -> None:
        self._pool = pool

    @staticmethod
    async def create_pool(dsn: str) -> asyncpg.Pool:
        return await asyncpg.create_pool(dsn=dsn, min_size=1, max_size=5)

    async def upsert_pattern(self, template: str, metadata: Dict[str, Any]) -> int:
        """Insert or update a log template. Returns the record ID."""
        async with self._pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    "SELECT id, count FROM log_patterns WHERE template = $1",
                    template
                )
                if row:
                    new_count = row["count"] + 1
                    await conn.execute(
                        "UPDATE log_patterns SET count = $1, updated_at = $2 WHERE id = $3",
                        new_count,
                        datetime.now(timezone.utc),
                        row["id"],
                    )
                    return row["id"]
                else:
                    record = await conn.fetchrow(
                        "INSERT INTO log_patterns (template, count, metadata) VALUES ($1, $2, $3) RETURNING id",
                        template,
                        1,
                        metadata,
                    )
                    return record["id"]

    async def list_patterns(self, limit: int = 100) -> List[LogPatternRecord]:
        query = (
            "SELECT id, template, count, metadata, created_at, updated_at"
            " FROM log_patterns ORDER BY updated_at DESC LIMIT $1"
        )
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(query, limit)
        return [self._row_to_record(row) for row in rows]

    @staticmethod
    def _row_to_record(row: asyncpg.Record) -> LogPatternRecord:
        return LogPatternRecord(
            id=row["id"],
            template=row["template"],
            count=row["count"],
            metadata=row["metadata"],
            created_at=row["created_at"],
            updated_at=row["updated_at"],
        )


###############################################################################
# SERVICE LAYER                                                                #
###############################################################################

class LogPatternService:
    """Service layer that manages Drain3 and pattern persistence."""

    def __init__(self, repo: LogPatternRepository, loki_base: str, query: str) -> None:
        self._repo = repo
        self._loki_base = loki_base.rstrip('/')
        self._query = query
        self._http_client = httpx.AsyncClient(timeout=10)
        # Configure Drain3 template miner
        config = TemplateMinerConfig()
        config.load(None)
        self._template_miner = TemplateMiner(config)
        # Prometheus metrics
        self._poll_count = Counter('lognexus_poll_total', 'Total number of log poll executions')
        self._new_templates = Counter('lognexus_new_templates_total', 'Number of new log templates detected')
        self._poll_duration = Histogram('lognexus_poll_duration_seconds', 'Duration of log poll in seconds')

        self._last_ts = int(time.time())  # Track last query timestamp

    async def close(self) -> None:
        await self._http_client.aclose()

    async def poll_logs(self) -> None:
        """Fetch logs from Loki since the last poll and process them."""
        with self._poll_duration.time():
            self._poll_count.inc()
            try:
                logs = await self._fetch_logs()
            except Exception as exc:  # noqa: BLE001
                logger.error('log_fetch_failed', error=str(exc))
                return
            for line in logs:
                template, change_type = self._template_miner.add_log_message(line)
                if change_type and change_type == 'new_template':
                    self._new_templates.inc()
                    # Persist the new template
                    await self._repo.upsert_pattern(template, metadata={})
                    logger.info('new_log_template', template=template)

    async def _fetch_logs(self) -> List[str]:
        """Retrieve logs from Loki via the /loki/api/v1/query_range endpoint."""
        now = int(time.time())
        start_ns = self._last_ts * 1_000_000_000
        end_ns = now * 1_000_000_000
        self._last_ts = now
        params = {
            'query': self._query,
            'start': start_ns,
            'end': end_ns,
            'limit': 1000,
            'direction': 'forward',
        }
        url = f"{self._loki_base}/loki/api/v1/query_range"
        response = await self._http_client.get(url, params=params)
        response.raise_for_status()
        data = response.json()
        result = data.get('data', {}).get('result', [])
        logs: List[str] = []
        for stream in result:
            for value in stream.get('values', []):
                # Each value is [timestamp, logLine]
                logs.append(value[1])
        return logs


###############################################################################
# FASTAPI INITIALIZATION                                                       #
###############################################################################

app = FastAPI(title="Log Nexus Pro", version="1.0.0")
app.mount("/metrics", make_asgi_app())

async def get_repo() -> LogPatternRepository:
    dsn = os.getenv('LOG_DB_DSN')
    if not dsn:
        raise RuntimeError('LOG_DB_DSN not set')
    if not hasattr(get_repo, '_pool'):
        get_repo._pool = await LogPatternRepository.create_pool(dsn)  # type: ignore[attr-defined]
    return LogPatternRepository(get_repo._pool)  # type: ignore[attr-defined]

async def get_service(repo: LogPatternRepository = Depends(get_repo)) -> LogPatternService:
    loki_base = os.getenv('LOKI_BASE_URL', 'http://omni-loki:3100')
    query = os.getenv('LOG_QUERY', '{job="app"}')
    if not hasattr(get_service, '_service'):
        get_service._service = LogPatternService(repo, loki_base, query)  # type: ignore[attr-defined]
    return get_service._service  # type: ignore[attr-defined]


###############################################################################
# ROUTES                                                                      #
###############################################################################

@app.get('/health', tags=['system'])
async def health() -> JSONResponse:
    return JSONResponse({'status': 'ok'})


@app.get('/ready', tags=['system'])
async def ready(repo: LogPatternRepository = Depends(get_repo)) -> JSONResponse:
    try:
        await repo.list_patterns(limit=1)
    except Exception as exc:  # noqa: BLE001
        logger.error('readiness_failed', error=str(exc))
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail='Database unavailable')
    return JSONResponse({'status': 'ready'})


@app.get('/api/v1/patterns', response_model=List[LogPatternRead], tags=['patterns'])
async def list_patterns(limit: int = 100, repo: LogPatternRepository = Depends(get_repo)) -> List[LogPatternRead]:
    records = await repo.list_patterns(limit)
    return [LogPatternRead(**record.__dict__) for record in records]


@app.post('/api/v1/poll', tags=['patterns'])
async def trigger_poll(background_tasks: BackgroundTasks, service: LogPatternService = Depends(get_service)) -> JSONResponse:
    background_tasks.add_task(service.poll_logs)
    return JSONResponse({'message': 'Log polling scheduled'})


###############################################################################
# BACKGROUND POLLER                                                            #
###############################################################################

async def periodic_poll(service: LogPatternService, interval: int) -> None:
    while True:
        try:
            await service.poll_logs()
        except Exception as exc:  # noqa: BLE001
            logger.error('polling_error', error=str(exc))
        await asyncio.sleep(interval)


@app.on_event('startup')
async def on_startup() -> None:
    repo = await get_repo()
    service = await get_service(repo)
    interval = int(os.getenv('POLL_INTERVAL_SECONDS', '60'))
    asyncio.create_task(periodic_poll(service, interval))


@app.on_event('shutdown')
async def on_shutdown() -> None:
    service = await get_service()
    await service.close()
